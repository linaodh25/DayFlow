// lib/widgets/app_drawer.dart (WITH LOCALIZATION)
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../blocs/navigation/navigation_cubit.dart';
import '../blocs/theme/theme_cubit.dart';
import '../theme/app_theme.dart';
import '../utils/navigation_localizations.dart';
import '../services/firebase_auth_service.dart';
import '../utils/routes.dart';

class AppDrawer extends StatelessWidget {
  const AppDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    final themeCubit = context.watch<ThemeCubit>();
    final isDark = themeCubit.isDarkMode;
    final navL10n = NavigationLocalizations.of(context);

    return Drawer(
      child: SafeArea(
        child: Column(
          children: [
            // Drawer Header
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: isDark
                      ? [AppTheme.primaryDark, AppTheme.secondaryDark]
                      : [AppTheme.primaryLight, AppTheme.secondaryLight],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 64,
                    height: 64,
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.2),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: const Icon(
                      Icons.water_drop_rounded,
                      size: 36,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    navL10n.appName,
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    navL10n.yourSmartDailyPlanner,
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.white.withValues(alpha: 0.9),
                    ),
                  ),
                ],
              ),
            ),

            // Drawer Items
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(vertical: 8),
                children: [
                  _DrawerItem(
                    icon: Icons.check_circle_outline,
                    title: navL10n.tasks,
                    subtitle: navL10n.manageTodos,
                    onTap: () {
                      context.read<NavigationCubit>().setIndex(0);
                      Navigator.pop(context);
                    },
                  ),
                  _DrawerItem(
                    icon: Icons.note_outlined,
                    title: navL10n.notes,
                    subtitle: navL10n.quickIdeas,
                    onTap: () {
                      context.read<NavigationCubit>().setIndex(1);
                      Navigator.pop(context);
                    },
                  ),
                  _DrawerItem(
                    icon: Icons.calendar_today_outlined,
                    title: navL10n.calendar,
                    subtitle: navL10n.planSchedule,
                    onTap: () {
                      context.read<NavigationCubit>().setIndex(2);
                      Navigator.pop(context);
                    },
                  ),
                  _DrawerItem(
                    icon: Icons.track_changes,
                    title: navL10n.habits,
                    subtitle: navL10n.trackHabits,
                    onTap: () {
                      context.read<NavigationCubit>().setIndex(3);
                      Navigator.pop(context);
                    },
                  ),
                  const Divider(height: 32, indent: 16, endIndent: 16),
                  _DrawerItem(
                    icon: Icons.bar_chart_rounded,
                    title: navL10n.statistics,
                    subtitle: navL10n.viewProgress,
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.pushNamed(context, Routes.habitStats);
                    },
                  ),
                  _DrawerItem(
                    icon: Icons.settings_outlined,
                    title: navL10n.settings,
                    subtitle: navL10n.customizeExperience,
                    onTap: () {
                      context.read<NavigationCubit>().setIndex(4);
                      Navigator.pop(context);
                    },
                  ),
                ],
              ),
            ),

            // Bottom Section
            const Divider(height: 1),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  // Theme Toggle
                  ListTile(
                    contentPadding: const EdgeInsets.symmetric(horizontal: 8),
                    leading: Icon(
                      isDark ? Icons.dark_mode : Icons.light_mode,
                      color: Theme.of(context).colorScheme.primary,
                    ),
                    title: Text(navL10n.theme),
                    trailing: Switch(
                      value: isDark,
                      onChanged: (value) {
                        themeCubit.toggleTheme();
                      },
                    ),
                  ),

                  const SizedBox(height: 16),

                  // Auth Buttons
                  StreamBuilder<User?>(
                    stream: FirebaseAuthService().authStateChanges,
                    builder: (context, snapshot) {
                      final isLoggedIn = snapshot.hasData;

                      if (isLoggedIn) {
                        return SizedBox(
                          width: double.infinity,
                          child: OutlinedButton.icon(
                            onPressed: () {
                              _showLogoutDialog(context);
                            },
                            icon: const Icon(Icons.logout),
                            label: Text(navL10n.logout),
                            style: OutlinedButton.styleFrom(
                              padding: const EdgeInsets.symmetric(vertical: 12),
                            ),
                          ),
                        );
                      } else {
                        return Column(
                          children: [
                            SizedBox(
                              width: double.infinity,
                              child: FilledButton.icon(
                                onPressed: () {
                                  Navigator.pop(context);
                                  Navigator.pushNamed(context, Routes.signup);
                                },
                                icon: const Icon(Icons.person_add),
                                label: Text(navL10n.signup),
                                style: FilledButton.styleFrom(
                                  padding: const EdgeInsets.symmetric(vertical: 12),
                                ),
                              ),
                            ),
                            const SizedBox(height: 8),
                            SizedBox(
                              width: double.infinity,
                              child: OutlinedButton.icon(
                                onPressed: () {
                                  Navigator.pop(context);
                                  Navigator.pushNamed(context, Routes.login);
                                },
                                icon: const Icon(Icons.login),
                                label: Text(navL10n.login),
                                style: OutlinedButton.styleFrom(
                                  padding: const EdgeInsets.symmetric(vertical: 12),
                                ),
                              ),
                            ),
                          ],
                        );
                      }
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showLogoutDialog(BuildContext context) {
    final navL10n = NavigationLocalizations.of(context);

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(navL10n.logout),
        content: Text(navL10n.areYouSureLogout),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(navL10n.cancel),
          ),
          FilledButton(
            onPressed: () async {
              await FirebaseAuthService().logout();
              if (context.mounted) {
                Navigator.pop(context); // Close dialog
                Navigator.pop(context); // Close drawer
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(navL10n.logoutSuccess),
                    duration: const Duration(seconds: 2),
                    behavior: SnackBarBehavior.floating,
                  ),
                );
              }
            },
            child: Text(navL10n.logout),
          ),
        ],
      ),
    );
  }
}

class _DrawerItem extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  const _DrawerItem({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.primary.withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Icon(
          icon,
          color: Theme.of(context).colorScheme.primary,
          size: 24,
        ),
      ),
      title: Text(
        title,
        style: const TextStyle(
          fontWeight: FontWeight.w600,
          fontSize: 16,
        ),
      ),
      subtitle: Text(
        subtitle,
        style: TextStyle(
          fontSize: 12,
          color: Theme.of(context).textTheme.bodyMedium?.color?.withValues(alpha: 0.7),
        ),
      ),
      onTap: onTap,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
    );
  }
}